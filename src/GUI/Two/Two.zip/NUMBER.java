package GUI.Two;

public class NUMBER {
	
	static final int STUDENT=1,TEACHER=2,STAFF=3,PREVIOUS=4;
	static final int INPUT=1,SEARCH=2,DELETE=3,PRINTALL=4,EXIT=5;

}
