package GUI.Two;

public class Menu {

	public static void MainMenu() {
		
		System.out.println("---------------Main Menu--------------");
		System.out.println("|1. Insert 2. Serach 3. Delete 4.Print 5. EXIT|");
		System.out.println("--------------------------------------");
		System.out.println("Selected Number");
		System.out.println("--------------------------------------");
	}
	
	public static void SubMenu() {
		
		System.out.println("---------------Sub Menu--------------");
		System.out.println("| 1.ST  2. TCR 3. STF 4. Previous 	 |");
		System.out.println("--------------------------------------");
		System.out.println("Selected Number=>");
		System.out.println("--------------------------------------");
	}

}
